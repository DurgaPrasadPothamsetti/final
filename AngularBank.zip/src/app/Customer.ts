export class Customer{
    AccountNum:number;
    Name:string;
    City:string;
    Password:string;
    Mobile:string;
    Balance:string;

    
    constructor(accno,name,city,password,mobile,balance){
        this.AccountNum=accno;
        this.Name=name;
        this.City=city;
        this.Password=password;
        this.Mobile=mobile;
        this.Balance=balance;
    }
}
