import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Customer } from '../Customer';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
// customer: Customer=new Customer(0,'','','','','');
  complete: any[];
  constructor(private custService: CustomerService) { }

  ngOnInit() {
  }
  login(username:string,password:string)
  {
   this.custService.login(username,password).subscribe(data => this.complete=data)
    alert("Logged In!");
  }
}
