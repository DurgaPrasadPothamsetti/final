import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Customer } from './Customer';

@Injectable({
  providedIn: 'root'
 })
 export class CustomerService {
  private bankServiceUrl = "http://localhost:8770";

  
  constructor(private httpService: HttpClient) { }
  
  public login(accNo: string, accPassword: string): Observable<Customer[]> {
  let loginUrl = this.bankServiceUrl + '/get';
  return this.httpService.get<Customer[]>(loginUrl);
  }
 

}