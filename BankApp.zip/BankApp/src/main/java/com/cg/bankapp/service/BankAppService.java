package com.cg.bankapp.service;



import java.util.List;


import com.cg.bankapp.bean.BankApp;
import com.cg.bankapp.exception.BankException;


public interface BankAppService {
		public BankApp addCustomer(BankApp bank) throws BankException;
		public List<BankApp> getCustomerDetails() throws BankException;
	   // public BankApp getDetailsById(int AccountNum) throws BankException;
	    public BankApp loginByUser(String Name, String Password) throws BankException;
	    
	    public int depositMoney(int AccountNum, int amount) throws BankException;
	    
	    public int withdrawMoney(int AccountNum,int amount) throws BankException;
	    
	    public int showBalance(int AccountNum) throws BankException;
	    
	    public int fundTransferUpdate(int accountNo1,int accountNo2,int amount) throws BankException;
		
}
