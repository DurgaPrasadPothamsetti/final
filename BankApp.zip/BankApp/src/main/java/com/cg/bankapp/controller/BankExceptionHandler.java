package com.cg.bankapp.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.bankapp.exception.BankException;



@ControllerAdvice
public class BankExceptionHandler {



	@ExceptionHandler(BankException.class)
	 public ResponseEntity<String> handleError(Exception ex){
		 return new ResponseEntity<String>("Oops!!"+ex.getMessage(),HttpStatus.CONFLICT);
		 
	 }

}