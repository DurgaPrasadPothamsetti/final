package com.cg.bankapp.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="BANKAPP")
public class BankApp implements Serializable{
	@Id
	@SequenceGenerator(name="AccountNum", sequenceName="ACC_SEQ",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="AccountNum")
	@Column(name="ACCOUNTNUM")
	private int AccountNum;
	
	@Column(name="NAME")
	private String Name;
	
	@Column(name="CITY")
	private String City;
	
	@Column(name="PASSWORD")
	private String Password;
	
	@Column(name="MOBILE")
	private String Mobile;
	
	@Column(name="BALANCE")
	private int Balance;
	
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}

	public int getBalance() {
		return Balance;
	}
	public void setBalance(int balance) {
		Balance = balance;
	}
	public int getAccountNum() {
		return AccountNum;
	}
	public void setAccountNum(int accountNum) {
		AccountNum = accountNum;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getMobile() {
		return Mobile;
	}
	public void setMobile(String mobile) {
		Mobile = mobile;
	}
	@Override
	public String toString() {
		return "BankApp [AccountNum=" + AccountNum + ", Name=" + Name + ", City=" + City + ", Password=" + Password
				+ ", Mobile=" + Mobile + ", Balance=" + Balance + "]";
	}
	
	
	
	
	
	
	
		
}
