package com.cg.bankapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bankapp.bean.BankApp;
import com.cg.bankapp.dao.BankAppDao;
import com.cg.bankapp.exception.BankException;

@Service
public class BankAppServiceImpl implements BankAppService {
	@Autowired
	BankAppDao dao;

	@Override
	public BankApp addCustomer(BankApp bank) throws BankException {
		// TODO Auto-generated method stub
		return dao.save(bank);
	}

	@Override
	public List<BankApp> getCustomerDetails() throws BankException {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public BankApp loginByUser(String Name, String Password) throws BankException {
		// TODO Auto-generated method stub
		 
		return null;
	}

	@Override
	public int depositMoney(int AccountNum, int amount) throws BankException {
		
		
		BankApp temp=dao.getDetailsById(AccountNum);
		int currentBalance=temp.getBalance();
		int updatedBalance=amount+currentBalance;
		temp.setBalance(updatedBalance);
		dao.save(temp);
		return updatedBalance;
		
		
	}

	@Override
	public int withdrawMoney(int AccountNum, int amount) throws BankException {
		
		BankApp temp=dao.getDetailsById(AccountNum);
		int currentBalance=temp.getBalance();
		int updatedBalance=currentBalance-amount;
		temp.setBalance(updatedBalance);
		dao.save(temp);
		return updatedBalance;
	}

	@Override
	public int showBalance(int AccountNum) throws BankException {
		
		BankApp bankApp=dao.getDetailsById(AccountNum);
		
		return bankApp.getBalance(); 
	}



	@Override
	public int fundTransferUpdate(int accountNo1, int accountNo2, int amount) throws BankException {
		BankApp temp1=dao.getDetailsById(accountNo1);
		int currentBalancein1=temp1.getBalance();
		BankApp temp2=dao.getDetailsById(accountNo2);
		int currentBalancein2=temp2.getBalance();
		
		
		int updatedBalance1=currentBalancein1-amount;
		int updatedBalance2=currentBalancein2+amount;
		
		temp1.setBalance(updatedBalance1);
		temp2.setBalance(updatedBalance2);
		dao.save(temp1);
		dao.save(temp2);
		return updatedBalance1;
		
	}


	
	
	

}
