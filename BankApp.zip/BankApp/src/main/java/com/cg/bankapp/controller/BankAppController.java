package com.cg.bankapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bankapp.bean.BankApp;
import com.cg.bankapp.exception.BankException;
import com.cg.bankapp.service.BankAppService;


@CrossOrigin(origins = "http://localhost:2524")
@RestController
public class BankAppController {
	@Autowired
	BankAppService bankService;
	
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public BankApp addCustomer(@RequestBody BankApp bank) throws BankException {
		
		return bankService.addCustomer(bank);
	}
	
	@RequestMapping("/get")
	public List<BankApp> getCustomerDetails() throws BankException {
		return bankService.getCustomerDetails();
	}
	
	
	@RequestMapping("/getbalance/{AccountNum}")
	public int getBalance(@PathVariable int AccountNum) throws BankException {
		return bankService.showBalance(AccountNum);
	}
	@RequestMapping(value="desposit/{accountId}/{amount}",method = RequestMethod.PUT)
	public ResponseEntity<String> desposit(@PathVariable int accountId,@PathVariable int amount) {
		int a=0;
		 try {
			a =bankService.depositMoney(accountId, amount);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ResponseEntity<String>("Your Deposited amount is "+ amount + "your current balance is"+ a ,HttpStatus.OK);
	}
	
	@RequestMapping(value="withdraw/{accountId}/{amount}",method = RequestMethod.PUT)
	public ResponseEntity<String> withdraw(@PathVariable int accountId,@PathVariable int amount) {
		int a=0;
		 try {
			a =bankService.withdrawMoney(accountId, amount);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ResponseEntity<String>("Your Withdrawn amount is "+ amount + "your current balance is"+ a ,HttpStatus.OK);
	}
	@RequestMapping(value="transfer/{accountId1}/{accountId2}/{amount}",method = RequestMethod.PUT)
	public ResponseEntity<String> transfer(@PathVariable int accountId1,@PathVariable int accountId2,@PathVariable int amount) {
		int a=0;
		 try {
			a =bankService.fundTransferUpdate(accountId1, accountId2, amount);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ResponseEntity<String>("Your Transfered amount is "+ amount + "your current balance is"+ a ,HttpStatus.OK);
	}
	
	
}
