package com.cg.bankapp.dao;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.bankapp.bean.BankApp;


@Repository
public interface BankAppDao extends JpaRepository<BankApp, Integer>{

	
	@Query("from BankApp where AccountNum=:acc")
	BankApp getDetailsById(@Param("acc") int accountNum);



}
